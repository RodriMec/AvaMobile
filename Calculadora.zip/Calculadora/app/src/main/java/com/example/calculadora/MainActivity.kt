import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main
import android.widget.Button

class MainActivity : AppCompatActivity() {

    private var operator = ""
    private var oldNumber = ""
    private var isNewOp = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Replace with your layout file

        val button0: Button = findViewById(R.id.button0)
        // Now you can use the 'button0' variable to interact with the button
    }

    private fun numberEvent() {
        val buttons = listOf(button0, button1, button2, button3, button4, button5, button6, button7, button8, button9, buttonDot)
        for (button in buttons) {
            button.setOnClickListener {
                if (isNewOp) {
                    editText.setText("")
                }
                isNewOp = false
                val text = editText.text.toString() + button.text.toString()
                editText.setText(text)
            }
        }
    }

    private fun operatorEvent() {
        val operators = listOf(buttonAdd, buttonSubtract, buttonMultiply, buttonDivide)
        for (button in operators) {
            button.setOnClickListener {
                oldNumber = editText.text.toString()
                operator = button.text.toString()
                isNewOp = true
            }
        }
    }

    private fun equalEvent() {
        buttonEquals.setOnClickListener {
            val newNumber = editText.text.toString()
            var result = 0.0
            when (operator) {
                "+" -> result = oldNumber.toDouble() + newNumber.toDouble()
                "-" -> result = oldNumber.toDouble() - newNumber.toDouble()
                "*" -> result = oldNumber.toDouble() * newNumber.toDouble()
                "/" -> result = oldNumber.toDouble() / newNumber.toDouble()
            }
            editText.setText(result.toString())
            isNewOp = true
        }
    }

    private fun clearEvent() {
        buttonClear.setOnClickListener {
            editText.setText("")
            isNewOp = true
        }
    }
}